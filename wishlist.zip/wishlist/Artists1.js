$(function(){
  $(".clearflex").on({
   mouseenter: function(){
    $(this).attr('src','./pros.png');
  },
  mouseleave: function(){
    $(this).attr('src','./pro_1.png');
  }
  });
  
});