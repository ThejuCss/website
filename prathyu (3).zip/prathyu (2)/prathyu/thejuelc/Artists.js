var flag = 0;
$(document).ready(function () {
    flag = 1;
    if(flag==1){
    $('.fullimage')
        .mouseover(function () {
        $(this).attr("src", "./pros.png");
    })
        .mouseout(function () {
        $(this).attr("src", "./pro_1.png");
        });
    }
if(flag==0){
$('.fullimage')

        .mouseover(function () {
        $(this).attr("src", "./pros.png");
    })
        .mouseout(function () {
        $(this).attr("src", "./pro_2.png");
});
}
if(flag==0){
    $('.fullimage')
        .mouseover(function () {
        $(this).attr("src", "./pros.png");
    })
        .mouseout(function () {
        $(this).attr("src", "./pro_3.png");
});
}
if(flag==0){
$('.fullimage')
        .mouseover(function () {
        $(this).attr("src", "./pros.png");
    })
        .mouseout(function () {
        $(this).attr("src", "./pro_4.png");
});
}
else{
$('.fullimage')
        .mouseover(function () {
        $(this).attr("src", "./pros.png");
    })
        .mouseout(function () {
        $(this).attr("src", "./pro_5.png");
});

}
});
